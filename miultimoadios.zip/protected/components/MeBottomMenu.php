<?php

class MeBottomMenu extends CWidget
{
    public function run()
    {
        $this->render('MeBottomMenu_View');
    }
}

?>