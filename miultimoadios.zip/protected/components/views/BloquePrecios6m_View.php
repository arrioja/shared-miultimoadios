<div class="bloque_precios">
    <div class="bloque_precios_titulo">
        Suscripción por 6 meses
    </div>
    <div class="bloque_precios_descripcion">
        <ul>
            <li> Ahorre un mes de suscripción con nuestro descuento! </li>
            <li> Obtenga todas las ventajas de la cuenta premium! </li>
            <li> Page de manera cómoda y segura con su TDC o cuenta Paypal.</li>
            <li> Olvídese de incómodas cuotas.</li>
            <li> Un servicio de alta calidad por un bajísimo monto.</li>
        </ul>
    </div>
    <div class="bloque_precios_precio">
        $ <br>
        10.00
    </div>
    <div class="bloque_precios_btn_pagar">
        <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
        <input type="hidden" name="cmd" value="_s-xclick">
        <input type="hidden" name="hosted_button_id" value="3WPDZ9EDUULWQ">
        <input type="image" src="https://www.paypalobjects.com/es_ES/ES/i/btn/btn_subscribeCC_LG.gif" border="0" name="submit" alt="PayPal. La forma rápida y segura de pagar en Internet.">
        <img alt="" border="0" src="https://www.paypalobjects.com/es_XC/i/scr/pixel.gif" width="1" height="1">
        </form>
    </div>
</div>





