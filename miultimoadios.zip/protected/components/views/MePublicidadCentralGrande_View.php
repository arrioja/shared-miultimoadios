<a href="<?=Yii::app()->createUrl('/site/page', array('view'=>'ventajas_premium'));?>"><img src="<?php echo Yii::app()->baseUrl; ?>/images/ads/big_ad_center.png" alt="" /></a>


