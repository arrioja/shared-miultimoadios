<?php  echo CHtml::image(Yii::app()->baseUrl.'/images/publicidad_200x200.png'); ?>


