<script type="text/javascript"><!--
    google_ad_client = "ca-pub-2979564965238447";
    /* publicidad_header */
    google_ad_slot = "5688823810";
    google_ad_width = 728;
    google_ad_height = 90;
    //-->
    </script>
    <script type="text/javascript"
    src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>

<?php  // echo CHtml::image(Yii::app()->baseUrl.'/images/publicidad_header.png'); ?>