<?php $this->beginContent('//layouts/main'); ?>
<div class="container">
	<div class="span-23">
		<div id="content">
			<?php echo $content; ?>
		</div><!-- content -->
	</div>
</div>
<?php $this->endContent(); ?>