<?php $this->pageTitle=Yii::app()->name." - Un ser querido le ha dejado un mensaje"; ?>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<div class="flash-error">
<?php echo "Con el objetivo de poder leer el mensaje que le ha dejado su ser querido, deberá seguir los siguientes pasos:
<ul>
    <li>
        Abra el mensaje de correo que ha recibido de parte de MiUltimoAdios.com y haga click en el enlace que se le ha enviado. Si el enlace no funciona, copie y pegue toda la dirección en su navegador preferido.
    </li>
    <li>
        Una vez que se abra la ventana, proporcionará 2 datos: Un a dirección de Email (en el cual usted recibió el mensaje), un código de autenticación, que lo recibió en el mismo correo de notificación de su mensaje.
    </li>
    <li>
        Haga click en el botón Recibir y listo.
    </li>
</ul>
";?>
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
