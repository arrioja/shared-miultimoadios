<?php
$this->breadcrumbs=array(
	'Rols'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List Rol', 'url'=>array('index')),
	array('label'=>'Manage Rol', 'url'=>array('admin')),
);
?>

<h1>Create Rol</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>