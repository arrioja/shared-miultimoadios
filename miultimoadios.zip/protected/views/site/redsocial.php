<?php
$this->pageTitle=Yii::app()->name . ' - Actividad en Redes Sociales';
?>
<!--
<div class="fb-like-box" data-href="http://www.facebook.com/miultimoadiosonline" data-width="700" data-show-faces="true" data-stream="false" data-header="true"></div>
<div class="fb-comments" data-href="http://www.miultimoadios.com" data-num-posts="10" data-width="700"></div>
-->
