<?php
$this->pageTitle=Yii::app()->name . ' - Sea Premium!';
$this->layout = 'column2users';
?>

<div class="acerca_ancho_box" >
    <div class="marco_top">       
        <br>
        <strong>Se encuentra a sólo un click de brindar paz y esperanza a su familia con su cuenta Premium!</strong>
        <br><br>
        <?php $this->widget('BloquePrecios6m',array('visible'=>true)); ?>
        <?php $this->widget('BloquePrecios12m',array('visible'=>true)); ?>
        <br><br><br><br><br><br><br><br><br><br>
        <br><br><br><br><br><br><br><br><br><br>
        <br><br><br>
    </div>

    
</div> <!-- login box -->
